﻿// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

using System;
using System.Collections.Generic;
using Microsoft.Spark.CSharp.Core;
using Microsoft.Spark.CSharp.Services;
using Microsoft.Spark.CSharp.Sql;
using System.IO;

namespace Microsoft.Spark.CSharp.Examples
{
    /// <summary>
    /// Mobius Pi example
    /// Calculate Pi
    /// Reference: https://github.com/apache/spark/blob/branch-1.5/examples/src/main/scala/org/apache/spark/examples/SparkPi.scala
    /// </summary>
    public static class PiExample
    {

        private static ILoggerService Logger;
        public static void Main(string[] args)
        {
            LoggerServiceFactory.SetLoggerService(Log4NetLoggerService.Instance); //this is optional - DefaultLoggerService will be used if not set
            Logger = LoggerServiceFactory.GetLogger(typeof(PiExample));

            var builder = SparkSession.Builder();
            //builder = builder.Config("spark.local.dir", Path.GetTempPath());
            builder = builder.Config("spark.sql.warehouse.dir", "alluxio://mnd-qg-spark02:19998/DFTEST121w1.txt");
            builder.AppName("TESTWINLINUX");
            var session = builder.GetOrCreate();
            var dbName = "Table";
            var tableName = "test";

            try
            {
                var ctx = session.SparkContext;
                var schemaPeople = new StructType(new List<StructField>
                                          {
                                              new StructField("id", new StringType()),
                                              new StructField("name", new StringType()),
                                              new StructField("age", new StringType())
                                          }.ToArray());

                var rddPeople = ctx.Parallelize(
                                            new[]{
                                          new object[] { "123", "Bill", "44" },
                                          new object[]{"145","gh","55"},
                                          new object[] { "123", "Bill", "44" }}
                                        );
                
                var df = session.CreateDataFrame(rddPeople, schemaPeople);
                var parquetPath = "alluxio://mnd-qg-spark02:19998/DFTEST121w121.txt";
                //var parquetPath = "file:///C:/Temp/Vtest/" + "DF_Parquet_Samples_BO_";
                //var sqlCtx = SqlContext.GetOrCreate(ctx);
                //var df = sqlCtx.Read().Parquet(parquetPath);
                //session.Sql(string.Format("CREATE DATABASE IF NOT EXISTS {0}", dbName));
                //session.Sql(string.Format("USE {0}", dbName));
                //df.Persist();
                //var s = ctx.TextFile("file:///C:/Temp/op.txt");
                //var strList = new List<string>();
                //strList.Add("test1");
                //var s = ctx.Parallelize(strList);
                //s.SaveAsTextFile("alluxio://mnd-qg-spark02:19998/textv2.txt");
                df.Write().Parquet(parquetPath);
                //var i = df.Count();
                //df.Show(20);
                //Logger.LogInfo(string.Format("table count in BO table database {0}: {1}", "BO", i));
                //df.Write().Mode(SaveMode.Overwrite).SaveAsTable(tableName);
                //df.ShowSchema();
                /* const int slices = 3;
                 var numberOfItems = (int)Math.Min(100000L * slices, int.MaxValue);
                 var values = new List<int>(numberOfItems);
                 for (var i = 0; i <= numberOfItems; i++)
                 {
                     values.Add(i);
                 }

                 var rdd = sparkContext.Parallelize(values, slices);

                 CalculatePiUsingAnonymousMethod(numberOfItems, rdd);

                 CalculatePiUsingSerializedClassApproach(numberOfItems, rdd);
 */
                Logger.LogInfo("Sample data push");
            }
            catch (Exception ex)
            {
                Logger.LogError("Error calculating Pi");
                Logger.LogException(ex);
            }

            session.Stop();

        }

        private static void CalculatePiUsingSerializedClassApproach(int n, RDD<int> rdd)
        {
            var count = rdd
                            .Map(new PiHelper().Execute)
                            .Reduce((x, y) => x + y);

            Logger.LogInfo(string.Format("(serialized class approach) Pi is roughly {0}.", 4.0 * count / n));
        }

        private static void CalculatePiUsingAnonymousMethod(int n, RDD<int> rdd)
        {
            var count = rdd
                            .Map(i =>
                            {
                                var random = new Random();
                                var x = random.NextDouble() * 2 - 1;
                                var y = random.NextDouble() * 2 - 1;

                                return (x * x + y * y) < 1 ? 1 : 0;
                            })
                            .Reduce((x, y) => x + y);

            Logger.LogInfo(string.Format("(anonymous method approach) Pi is roughly {0}.", 4.0 * count / n));
        }

        /// <summary>
        /// Serialized class used in RDD Map Transformation
        /// </summary>
        [Serializable]
        private class PiHelper
        {
            private readonly Random random = new Random();
            public int Execute(int input)
            {
                var x = random.NextDouble() * 2 - 1;
                var y = random.NextDouble() * 2 - 1;

                return (x * x + y * y) < 1 ? 1 : 0;
            }
        }
    }
}