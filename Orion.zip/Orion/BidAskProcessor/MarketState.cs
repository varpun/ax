﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BidAskProcessor
{
    public class MarketState
    {
        public int? id { get; set; }

        public long? ask { get; set; }

        public long? bid { get; set; }

        public long? sequenceNumber { get; set; }

        public long? settlementPrice { get; set; }

        public long? settlementDate { get; set; }

        public int? instrumetId { get; set; }

        public string deleted { get; set; }

        public long? bidSize { get; set; }

        public long? askSize { get; set; }
    }
}
