﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BidAskProcessor
{
    public class SecurityDefinitionMessage
    {
        public int marketId { get; set; }
        public String contractSymbol { get; set; }
        public String currency { get; set; }
        public int denominator { get; set; }
        public String hubAlias { get; set; }
        public short hubID { get; set; }
        public int incrementPrice { get; set; }
        public bool isCrackSpread { get; set; }
        public bool isSpread { get; set; }
        public int lotSize { get; set; }
        public String marketDesc { get; set; }
        //public DateTime maturityDate { get; set; }
        public int primaryMarketID { get; set; }
        public short numOfMarkets { get; set; }
        public int secondaryMarketID { get; set; }
        public short productID { get; set; }
        public short stripId { get; set; }
        public String stripName { get; set; }
        public String tradingStatus { get; set; }
        public int unityQtyDenominator { get; set; }

        public int JsonKey(DateTime date)
        {
            String format = "MMMyy";
            DateTime result;
            if (DateTime.TryParseExact(stripName, format, CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal,
                out result))
            {
                return monthDifference(date, result);
            }
            else
            {
                return -1;
            }
        }

        private int monthDifference(DateTime from, DateTime to)
        {
            return to.Month - from.Month + (to.Year - from.Year) * 12;
        }
    }
}
