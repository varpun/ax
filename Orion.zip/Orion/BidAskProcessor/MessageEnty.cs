﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BidAskProcessor
{
    public class MessageEnty
    {
        public int SequenceNumber { get; set; }
        public TimeSpan Time { get; set; }
        public string MessageType { get; set; }
        public string Topic { get; set; }
        public string Payload { get; set; }


        public static MessageEnty ParseFromString(string line)
        {
            var entity = new MessageEnty();
            if (!string.IsNullOrEmpty(line))
            {
                var parts = line.Split(';');
                entity.SequenceNumber = Int32.Parse(parts[0]);
                entity.Time = TimeSpan.Parse(parts[1]);
                entity.MessageType = parts[2];
                entity.Topic = parts[3];
                entity.Payload = parts[4];
            }
            return entity;
        }
    }
}
