﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace BidAskProcessor
{
    public struct MessageEntryUpdate
    {
        public int SequenceNumber { get; set; }
        public TimeSpan Time { get; set; }
        public String MessageType { get; set; }
        public String Topic { get; set; }
        public MarketState Update { get; set; }

        public static MessageEntryUpdate ParseFromEntry(MessageEnty entry)
        {
            MessageEntryUpdate update = new MessageEntryUpdate
            {
                SequenceNumber = entry.SequenceNumber,
                Time = entry.Time,
                MessageType = entry.MessageType,
                Topic = entry.Topic,
                Update = JsonConvert.DeserializeObject<MarketState>(entry.Payload)

            };
            return update;
        }
    }
}
