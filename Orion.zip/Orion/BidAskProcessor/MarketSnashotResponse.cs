﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BidAskProcessor
{
    public class MarketSnashotResponse
    {
        public List<MarketState> response { get; set; }
    }
}
