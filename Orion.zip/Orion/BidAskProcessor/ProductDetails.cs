﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BidAskProcessor
{
    class ProductDetails
    {
        public String Product { get; set; }
        public List<SecurityDefinitionMessage> SecDef { get; set; }
        public MarketState Snapshot { get; set; }
        public List<MessageEntryUpdate> Updates { get; set; }
        public int StartTime { get; set; }
    }
}
