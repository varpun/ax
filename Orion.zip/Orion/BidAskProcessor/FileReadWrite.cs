﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using NLog;


namespace BidAskProcessor
{
    public class FileReadWrite :IDisposable
    {
        private static ILogger _logger = LogManager.GetCurrentClassLogger();
        private List<ProductDetails> _productDetails = new List<ProductDetails>();
        private int _denominator=1;

        public void ReadCsvDataExtracted(String folder, List<string> files, String product, string contractsymbol, DateTime date)
        {
            var resultList = new ConcurrentBag<ProductDetails>();
            Parallel.ForEach(files, file =>
            {
                ProductDetails result = new ProductDetails();
                result.Product = product;
                //String brnPath = String.Format("{0}_{1}_{2}.txt", product, start, end);
                _logger.Info($"Processing file {file} for date {date}");
                var fileName = Path.GetFileNameWithoutExtension(file);
                var fileParts = fileName.Split('_');
                var start = fileParts[1];
                String path = file;
                List<MessageEnty> brentMessages = new List<MessageEnty>(10000);
                int instrumentId;
                try
                {
                    using (StreamReader reader = new StreamReader(path))
                    {
                        String line = reader.ReadLine();
                        MessageEnty secDefEntry = MessageEnty.ParseFromString(line);
                        SecurityDefinitionResponse secDef =
                            JsonConvert.DeserializeObject<SecurityDefinitionResponse>(secDefEntry.Payload);
                        line = reader.ReadLine();
                        MessageEnty marketState = MessageEnty.ParseFromString(line);
                        MarketSnashotResponse marketSnapshot =
                            JsonConvert.DeserializeObject<MarketSnashotResponse>(marketState.Payload);
                        line = reader.ReadLine();
                        while (line != null)
                        {
                            brentMessages.Add(MessageEnty.ParseFromString(line));
                            line = reader.ReadLine();
                        }

                        _logger.Info("Read {} message for {} product", brentMessages.Count, product);
                        result.SecDef = secDef.response[product];
                        instrumentId = result.SecDef
                                               .FirstOrDefault(p => p.contractSymbol.Equals(contractsymbol,
                                                   StringComparison.OrdinalIgnoreCase))
                                               ?.marketId ?? 0;
                        var denominatorPow = result.SecDef.FirstOrDefault(p => p.contractSymbol.Equals(contractsymbol, StringComparison.OrdinalIgnoreCase))?.denominator ?? 0;
                        _denominator = Convert.ToInt32(Math.Pow(10, denominatorPow));
                        result.Snapshot = marketSnapshot.response.FirstOrDefault(p => p.id == instrumentId);
                        result.Updates = brentMessages.Select(x => MessageEntryUpdate.ParseFromEntry(x)).Where(p => p.Update.instrumetId == instrumentId).ToList();
                        result.StartTime = Int32.Parse(start);
                    }
                    if (instrumentId != 0)
                    {
                        resultList.Add(result);
                    }

                }
                catch (Exception e)
                {
                    _logger.Error(e, "Reading exception");
                }
            });
            
            _productDetails= resultList.OrderBy(p => p.StartTime).ToList();
            //return result;
        }

        public void WriteDataCsv(string outputPath,string contractSymbol,DateTime date)
        {
            decimal lastBid = 0;
            decimal lastAsk = 0;
            if (_productDetails != null && _productDetails.Any())
            {
                var initialMarketState = _productDetails[0];
                if (initialMarketState.Snapshot != null)
                {
                    lastBid =_denominator==0?initialMarketState.Snapshot.bid ?? 0 : decimal.Divide((initialMarketState.Snapshot.bid ?? 0),_denominator);
                    lastAsk = _denominator == 0 ? initialMarketState.Snapshot.ask ?? 0: decimal.Divide((initialMarketState.Snapshot.ask ?? 0),_denominator);
                }
                var contractSymbolFileName = contractSymbol.Replace(':', ' ');
                var outputFileName = contractSymbolFileName + "_" + date.ToString("yyyyMMdd")+".csv";
                var exportPath = Path.Combine(outputPath, outputFileName);
                _logger.Info($"Exporting data to CSV for date {date}");
                using (var writer = new StreamWriter(exportPath))
                {
                    writer.WriteLine("DateTime,ContractSymbol,Bid,Ask");
                    foreach (var s in _productDetails)
                    {
                        foreach (var q in s.Updates)
                        {
                            try
                            {
                                if (q.Update.ask.HasValue)
                                {
                                    lastAsk = _denominator == 0? q.Update.ask.Value : decimal.Divide((q.Update.ask.Value),_denominator);
                                    WriteValue(date, q.Time, contractSymbol, lastBid, lastAsk, writer);
                                }
                                if (q.Update.bid.HasValue)
                                {
                                    lastBid = _denominator ==0? q.Update.bid.Value :decimal.Divide((q.Update.bid.Value),_denominator);
                                    WriteValue(date, q.Time, contractSymbol, lastBid, lastAsk, writer);
                                }
                                if (!string.IsNullOrEmpty(q.Update.deleted))
                                {
                                    if (q.Update.deleted.Equals("ASK", StringComparison.OrdinalIgnoreCase))
                                    {
                                        lastAsk = 0;
                                        WriteValue(date, q.Time, contractSymbol, lastBid, lastAsk, writer);
                                    }
                                    if (q.Update.deleted.Equals("BID", StringComparison.OrdinalIgnoreCase))
                                    {
                                        lastBid = 0;
                                        WriteValue(date, q.Time, contractSymbol, lastBid, lastAsk, writer);
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                _logger.Error(ex,"Error writing record");
                            }
                        }
                    }
                }
                
            }
        }

        public void WriteValue(DateTime date,TimeSpan q,string contractSymbol,decimal lastBid,decimal lastAsk,StreamWriter writer)
        {
            if (q > new TimeSpan(0, 0, 1) && q < new TimeSpan(2, 0, 2))
            {
                writer.WriteLine($"{date.AddDays(1).Add(q).ToString("dd/MM/yyyy HH:mm:ss.ffffff")},{contractSymbol},{lastBid},{lastAsk}");
            }
            else
            {
                writer.WriteLine($"{date.Add(q).ToString("dd/MM/yyyy HH:mm:ss.ffffff")},{contractSymbol},{lastBid},{lastAsk}");
            }
        }

        public void Dispose()
        {
        }
    }
}
