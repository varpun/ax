﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using NLog;

namespace BidAskProcessor
{
    public class BidAskProcessor
    {
        private static ILogger _logger = LogManager.GetCurrentClassLogger();
        public static string ContractCodes { get; } = "FGHJKMNQUVXZ";

        public void ReadWriteCsvData()
        {
            var folder = ConfigurationManager.AppSettings["FileLocation"];
            var startDateStr = ConfigurationManager.AppSettings["StartDate"];
            var endDateStr = ConfigurationManager.AppSettings["EndDate"];
            var startDate = DateTime.Parse(startDateStr);
            var endDate = DateTime.Parse(endDateStr);
            var fileStart = ConfigurationManager.AppSettings["FileStart"];
            var contractSymbol = ConfigurationManager.AppSettings["ContractSymbol"];
            var outputDir = ConfigurationManager.AppSettings["OutputFolderLoc"];
            
            for (var i = startDate; i <= endDate; i = i.AddDays(1))
            {
                _logger.Info($"Start processing for date {i}");
                if (i.DayOfWeek == DayOfWeek.Saturday || i.DayOfWeek == DayOfWeek.Sunday)
                {
                    continue;
                }
                var folderDate = Path.Combine(folder, i.ToString("yyyyMMdd"));
                var filesArray = Directory.GetFiles(folderDate, $"{fileStart}*.txt").ToList();
                using (var fileIO = new FileReadWrite())
                {
                    fileIO.ReadCsvDataExtracted(folderDate,filesArray,fileStart,contractSymbol,i);
                    fileIO.WriteDataCsv(outputDir,contractSymbol,i);
                }
            }
        }

        
    }
}
