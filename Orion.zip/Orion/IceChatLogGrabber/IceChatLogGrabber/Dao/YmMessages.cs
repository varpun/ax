﻿using System;
using IceChatLogGrabber.Model;

namespace IceChatLogGrabber.Dao
{
    public class YmMessages
    {
        public int MessageId { get; set; }

        public String IceMessageId { get; set; }
        public String GroupName { get; set; }
        public DateTime TimestampRecieved { get; set; }
        public String MessageText { get; set; }
        public int BrokerId { get; set; }

        //Unmapped property
        public string UserName { get; set; }

        public static YmMessages FromJsonModel(IdpMessagePayload payload)
        {
            return new YmMessages()
            {
                IceMessageId = payload.blastId ?? payload.id,
                UserName = payload.sender.username,
                TimestampRecieved = payload.timestamp,
                MessageText = payload.message
            };
        }

        public String HashKey => $"{IceMessageId}_{BrokerId}_{MessageText}";


        public override string ToString()
        {
            return $"{nameof(MessageId)}: {MessageId}, {nameof(IceMessageId)}: {IceMessageId}, {nameof(GroupName)}: {GroupName}, {nameof(TimestampRecieved)}: {TimestampRecieved}, {nameof(MessageText)}: {MessageText}, {nameof(BrokerId)}: {BrokerId}";
        }
    }
}
