﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IceChatLogGrabber.Dao
{
    public class BrokerGroups
    {
        public int Id { get; set; }

        public String GroupName { get; set; }

    }
}
