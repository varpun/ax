﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using MoreLinq;
using NLog;

namespace IceChatLogGrabber.Dao
{
    public class HamlMessageDao
    {
        private static Logger _log = LogManager.GetCurrentClassLogger();
        private static Logger _messageLog = LogManager.GetLogger("MessageLog");
        private readonly string _connectionString;

        private Dictionary<string, Brokers> _brokers;
        private List<BrokerGroups> _brokerGroups;
        private Dictionary<String, YmMessages> _messageCache=new Dictionary<string, YmMessages>();
        private List<String> _ignoredUsers;
        private String _defaultGroup;


        public HamlMessageDao()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["HamlDb"].ConnectionString;
            _defaultGroup = ConfigurationManager.AppSettings["DefaultGroup"] ?? "Fuel";
            _ignoredUsers = (ConfigurationManager.AppSettings["IgnoreUsers"] ?? "").Split(',').ToList();
            ReadBrokersAndGroups();

        }

        private void ReadBrokersAndGroups()
        {
            _brokers = new Dictionary<string, Brokers>();
            _brokerGroups = new List<BrokerGroups>();
            using (var sqlConnection = new SqlConnection(_connectionString))
            {
                sqlConnection.Open();
                var brokers = sqlConnection.Query<Brokers>(
                    "Select * from brokers ");


                foreach (Brokers broker in brokers)
                {
                    _brokers[broker.YahooId] = broker;
                }

                _brokerGroups = sqlConnection.Query<BrokerGroups>(
                    "Select * from broker_groups").ToList();

                var messages = sqlConnection.Query<YmMessages>("Select * from ym_messages where timestamp_recieved > CONVERT (date, SYSDATETIME()) ");
                foreach (YmMessages message in messages)
                {
                    _messageCache[message.HashKey] = message;
                }

            }
            _log.Info("{0} broker and {1} group loaded",_brokers.Count,_brokerGroups.Count);
        }

        public void SaveMessageIfNotExsist(List<YmMessages> yahooMessages)
        {
            var filteredMessages =
                        yahooMessages.Where(x => !_messageCache.ContainsKey(x.HashKey) && !_ignoredUsers.Contains(x.UserName)).ToList();
            LogForTracing(filteredMessages);
            foreach (IEnumerable<YmMessages> batch in filteredMessages.Batch(10))
            {
                for (int j = 0; j < 3; j++)
                {
                    try
                    {
                        SaveMessageIfNotExsistInternal(batch);
                        break;
                    }
                    catch (Exception e)
                    {
                        _log.Warn(e,"Saving exception retrying {0}",j);
                    }
                    _log.Error("Lost message pack");
                }
            }
        }

        private void LogForTracing(List<YmMessages> filteredMessages)
        {
            foreach (var message in filteredMessages)
            {
                _messageLog.Info(
                                        "We got the following message sent time {0} id {1} user {2} message {3} ",
                                        message.TimestampRecieved, message.IceMessageId, message.UserName, message.MessageText);
            }
        }


        private void SaveMessageIfNotExsistInternal(IEnumerable<YmMessages> yahooMessages)
        {
            
                using (var sqlConnection = new SqlConnection(_connectionString))
                {
                    sqlConnection.Open();
                    MapMessagesToBroker(sqlConnection,yahooMessages);
                    using (SqlTransaction transaction = sqlConnection.BeginTransaction())
                    {
                        foreach (var message in yahooMessages)
                        {

                            var upsertCommand = @"BEGIN
   IF NOT EXISTS (Select * from ym_messages where ice_message_id=@IceMessageId and message_text=@MessageText)
   BEGIN
       INSERT INTO ym_messages ([group_name],[timestamp_recieved],[message_text],[ice_message_id],[broker_id]) VALUES (@Group,@TimestampRecieved,@MessageText,@IceMessageId,@BrokerId)
   END
END";

                                sqlConnection.Execute(upsertCommand,
                                    new
                                    {
                                        Group= _defaultGroup,
                                        TimestampRecieved = message.TimestampRecieved,
                                        IceMessageId = message.IceMessageId,
                                        MessageText = message.MessageText,
                                        BrokerId = message.BrokerId

                                    }, transaction,90);
                                _log.Info("Message inserted {0}",message);
                                _messageCache[message.HashKey] = message;
                            
                        }
                        transaction.Commit();
                    }
                }
            
        }

        private void MapMessagesToBroker(SqlConnection sqlConnection, IEnumerable<YmMessages> yahooMessages)
        {
            foreach (var message in yahooMessages)
            {
                if (!_brokers.ContainsKey(message.UserName))
                {
                    InsertBroker(sqlConnection, message);
                }
                else
                {
                    message.BrokerId = _brokers[message.UserName].BrokerId;
                }
            }
        }

        private void InsertBroker(SqlConnection sqlConnection, YmMessages message)
        {
            var insertCommand = @"BEGIN
   IF NOT EXISTS (SELECT * FROM brokers 
                   WHERE yahoo_id = @YahooId)
   BEGIN
       INSERT INTO brokers (yahoo_id)
       VALUES (@YahooId)
   END
END";
            int count=sqlConnection.Execute(insertCommand, new {YahooId = message.UserName});
            
            var newBroker =
                sqlConnection.Query<Brokers>("select * from brokers where yahoo_id = @YahooId",
                    new {YahooId = message.UserName}).First();
            if (count > 0)
            {
                var brokerGroup = _brokerGroups.FirstOrDefault(x => x.GroupName == _defaultGroup);
                if (brokerGroup != null)
                {
                    sqlConnection.Execute(
                        "insert INTO broker_group_mapping ([broker_id],[group_id]) VALUES (@BrokerId,@GroupId)",
                        new
                        {
                            BrokerId = newBroker.BrokerId,
                            GroupId = brokerGroup.Id
                        }
                    );
                }
            }

            _brokers.Add(newBroker.YahooId,newBroker);
            message.BrokerId = newBroker.BrokerId;
        }
    }
}
