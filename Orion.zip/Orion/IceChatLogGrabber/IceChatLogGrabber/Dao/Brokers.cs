﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IceChatLogGrabber.Dao
{
    public class Brokers
    {
        public int BrokerId { get; set; }

        public string YahooId { get; set; }

    }
}
