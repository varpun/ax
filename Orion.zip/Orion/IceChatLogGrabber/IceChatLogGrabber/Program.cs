﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using IceChatLogGrabber.Dao;
using IceChatLogGrabber.Polling;
using Topshelf;

namespace IceChatLogGrabber
{
    class Program
    {
        static void Main(string[] args)
        {
            Dapper.DefaultTypeMap.MatchNamesWithUnderscores = true;
            String appFolder = ConfigurationManager.AppSettings["IceLogFolder"];
            HostFactory.Run(x =>                                 //1
            {
                x.Service<FileManager>(s=>
                {
                    s.ConstructUsing(name => new FileManager(appFolder));
                    s.WhenStarted(tc => tc.Start());              //4
                    s.WhenStopped(tc => tc.Stop());
                });
                x.RunAsLocalSystem();
                x.SetDescription("Mandara-Ice Chat log grabber");
                x.SetDisplayName("Mandara.IceChatGrabber");
                x.SetServiceName("IceChatGrabber");
                x.UseNLog();
            });

        }
    }
}
