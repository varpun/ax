﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using IceChatLogGrabber.Dao;
using IceChatLogGrabber.Model;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NLog;
using Topshelf;

namespace IceChatLogGrabber.Polling
{
    public class FileManager: ServiceControl
    {
        private FileSystemWatcher _watcher;
        private Logger _log = LogManager.GetCurrentClassLogger();
        private readonly ConcurrentDictionary<String, int> _fileNameWithPosition;
        private readonly BlockingCollection<String> _fileNameToCheck;
        private readonly string _filePath;
        
        private static string _liveFileName = "log.txt";
        private static string _fileFilter = _liveFileName+"*";

        private CancellationTokenSource _source = new CancellationTokenSource();
        private readonly JsonParser _jsonParser;
        private HamlMessageDao _messageDao;
        private Timer _timer;


        public FileManager(String path)
        {
            _filePath = path;
            _messageDao = new HamlMessageDao();
            _watcher = new FileSystemWatcher();
            _watcher.IncludeSubdirectories = false;
            _watcher.Path = _filePath;
            _watcher.NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite | NotifyFilters.Size;
            _watcher.Created += Watcher_Created;
            _watcher.Changed += Watcher_Changed;
            _watcher.Renamed += Watcher_Renamed;
            _watcher.Deleted += Watcher_Deleted;
            _watcher.Filter = _fileFilter;
            _fileNameWithPosition = new ConcurrentDictionary<string, int>();
            _fileNameToCheck = new BlockingCollection<string>(new ConcurrentQueue<string>());
            _jsonParser = new JsonParser();
        }

        private void Watcher_Deleted(object sender, FileSystemEventArgs e)
        {
            _log.Info("{0} {1} {2} ",e.ChangeType,e.FullPath,e.Name);
            int previousPosition;
            _fileNameWithPosition.TryRemove(e.Name,out previousPosition);
        }

        private void Watcher_Renamed(object sender, RenamedEventArgs e)
        {
            _log.Info("{0} {1} {2} ", e.ChangeType, e.FullPath, e.Name);
            _fileNameToCheck.Add(e.OldName);
        }

        private void Watcher_Changed(object sender, FileSystemEventArgs e)
        {
            _log.Info("{0} {1} {2} ", e.ChangeType, e.FullPath, e.Name);
            _fileNameToCheck.Add(e.Name);
        }

        private void Watcher_Created(object sender, FileSystemEventArgs e)
        {
            _log.Info("{0} {1} {2} ", e.ChangeType, e.FullPath, e.Name);
            if (e.Name == _liveFileName)
            {
                _fileNameToCheck.Add(e.Name);
            }
        }

        public void Start()
        {
            _timer = new Timer(PollFile,new object(), TimeSpan.FromSeconds(5), TimeSpan.FromMilliseconds(300));
            _log.Info("Start manager");
            
            var fileList= Directory.GetFiles(_filePath, _fileFilter).Select(x=> Path.GetFileName(x)).ToList();
            fileList.ForEach(x =>
            {
                _fileNameWithPosition[x] = 0;
                _fileNameToCheck.Add(x);
            });
            _watcher.EnableRaisingEvents = true;

            var worker = new BackgroundWorker();
            worker.WorkerSupportsCancellation = false;
            worker.DoWork += _worker_DoWork;
            worker.RunWorkerAsync();

        }

        private void PollFile(object state)
        {
            if (Monitor.TryEnter(state))
            {
                try
                {
                    var fileName = Path.Combine(_filePath, _liveFileName);
                    var file = new FileInfo(fileName);
                    long size = file.Length;
                    if (_fileNameWithPosition[_liveFileName] < size)
                    {
                        _log.Info("Poller submitted live file");
                        _fileNameToCheck.Add(_liveFileName);
                    }

                }
                catch (Exception e)
                {
                    _log.Error(e, "Error poling file");
                }
                finally
                {
                    Monitor.Exit(state);
                }

            }
        }

        private void _worker_DoWork(object sender, DoWorkEventArgs e)
        {
            while (!_source.IsCancellationRequested)
            {
                try
                {
                    MainLoop();
                }
                catch (OperationCanceledException )
                {
                    _log.Info("Main loop stopping");   
                }
                catch (Exception ex)
                {
                    _log.Error(ex,"unhandled exception");
                }
            }

        }

        private void MainLoop()
        {
            List<string> fileToCheck = new List<string>();
            if (_fileNameToCheck.Count == 0)
            {
                //We blocking here
                string newValue = _fileNameToCheck.Take(cancellationToken: _source.Token);
                fileToCheck.Add(newValue);
            }
            else
            {
                while (_fileNameToCheck.Count > 0)
                {
                    string newValue = _fileNameToCheck.Take(cancellationToken: _source.Token);
                    fileToCheck.Add(newValue);
                }
            }


            fileToCheck = fileToCheck.Distinct().ToList();
            //Process new file changes
            foreach (var fileName in fileToCheck)
            {
                var path = Path.Combine(_filePath, fileName);
                if(!File.Exists(path) ) continue;
                try
                {
                    using (FileStream sr = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {

                        long lenght = sr.Length;
                        int currentSeek;
                        if (!_fileNameWithPosition.TryGetValue(fileName, out currentSeek))
                        {
                            currentSeek =0;
                        }

                        if (lenght < currentSeek)
                        {
                            currentSeek = 0;
                        }

                        if (currentSeek < lenght)
                        {
                            sr.Seek(currentSeek + 1, SeekOrigin.Begin);
                            int toRead = Convert.ToInt32(lenght - currentSeek);
                            byte[] dataBytes = new byte[toRead];
                            sr.Read(dataBytes, 0, toRead);

                            string s = Encoding.Default.GetString(dataBytes);
                            string[] lines = s.Split(new string[] {Environment.NewLine},
                                StringSplitOptions.RemoveEmptyEntries);
                            _log.Info("Lines {0}", lines.Length);
                            //_log.Info(s);
                            _fileNameWithPosition[fileName] = Convert.ToInt32(lenght);
                            ParseLines(lines, fileName);
                        }
                    }
                }
                catch (Exception e)
                {
                    _log.Error(e,"Unhandled exception during file reading, skipping file");
                }
            }

        }

        private void ParseLines(string[] lines,String fileName)
        {
            _log.Info("Processing {0} lines {1}",fileName,lines.Length);
            List<YmMessages> parsedResults = _jsonParser.ParseLines(lines);
            if (parsedResults.Count > 0)
            {
                _log.Info("Processing {0} found messages {1}", fileName, parsedResults.Count);
                _messageDao.SaveMessageIfNotExsist(parsedResults);
            }
        }

        public void Stop()
        {
            _source.Cancel();
            _log.Info("Stop manager");
            _watcher.Dispose();
        }

        public bool Start(HostControl hostControl)
        {
            Start();
            return true;
        }

        public bool Stop(HostControl hostControl)
        {
            Stop();
            return true;
        }
    }
}
