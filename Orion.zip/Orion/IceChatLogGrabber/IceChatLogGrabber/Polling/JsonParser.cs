using System;
using System.Collections.Generic;
using System.Linq;
using IceChatLogGrabber.Dao;
using IceChatLogGrabber.Model;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NLog;

namespace IceChatLogGrabber.Polling
{
    public class JsonParser
    {
        private static Logger _log = LogManager.GetCurrentClassLogger();


        public bool IsChatMessage(JObject jObject)
        {
            var token = jObject.SelectToken(".payload.args");
            if (token != null && token.Children().Count() > 2)
            {
                var commandType = token.Children().Take(2).Last().ToString();
                if (token.Children().Count() > 2 && commandType.Contains("chatmessage"))
                {
                    if (token.Children().Take(3).Last().Children().First().HasValues)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public IEnumerable<YmMessages> ProcessJsonMessage(JObject jObject)
        {
            List<YmMessages> results=new List<YmMessages>();
            if (IsChatMessage(jObject))
            {
                try
                {
                    var token = jObject.SelectToken(".payload.args");
                    var drillDownToken = token.Children().Take(3).Last().Children().First().Values().First();
                    var models = drillDownToken.ToObject<JsonModel>();
                    foreach (var messagePayload in models.idpMessagePayload)
                    {
                        YmMessages message = YmMessages.FromJsonModel(messagePayload);
                        results.Add(message);
                    }
                }
                catch (Exception e)
                {
                    _log.Error(e,"Error parsing value");
                }
            }
            return results;
        }

        public static bool IsValidJson(string strInput,out JObject jsonObject)
        {
            strInput = strInput.Trim();
            if ((strInput.StartsWith("{") && strInput.EndsWith("}")) || //For object
                (strInput.StartsWith("[") && strInput.EndsWith("]"))) //For array
            {
                try
                {
                    var obj = JObject.Parse(strInput);
                    jsonObject = obj;
                    return true;
                }
                catch //some other exception
                {
                }
            }

            jsonObject = null;
            return false;

        }

        public List<YmMessages> ParseLines(string[] lines)
        {
            var parsedResults = new List<YmMessages>();
            foreach (var line in lines)
            {
                if (line != null)
                {
                    try
                    {
                        int jsonStart = line.IndexOf("{", StringComparison.Ordinal);
                        int jsonEnd = line.LastIndexOf("}", StringComparison.Ordinal);
                        if (jsonStart > 0 && jsonEnd > 0)
                        {
                            int length = jsonEnd - jsonStart + 1;
                            if(length<1) continue;
                            var subString = line.Substring(jsonStart, jsonEnd - jsonStart + 1);
                            JObject o;
                            if (JsonParser.IsValidJson(subString, out o))
                            {
                                var parsedMessages = ProcessJsonMessage(o);
                                foreach (var message in parsedMessages)
                                {
                                    message.UserName = message.UserName.ToLower();
                                    message.TimestampRecieved = message.TimestampRecieved.ToLocalTime();
                                    _log.Info(
                                        "We got the following message sent time {0} id {1} user {2} message {3} ",
                                        message.TimestampRecieved, message.IceMessageId, message.UserName, message.MessageText);
                                    parsedResults.Add(message);
                                }
                            }
                            else
                            {
                                if (subString.Contains("...") && subString.Contains("chatmessage"))
                                {
                                    _log.Warn("We might lost message here: {0}", subString);
                                }
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        _log.Error(e);
                    }
                }
            }
            return parsedResults;
        }
    }
}