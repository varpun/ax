﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IceChatLogGrabber.Model
{
    public class JsonModel
    {
        public IList<IdpMessagePayload> idpMessagePayload { get; set; }
        public object webIceMessagePayload { get; set; }
        public object structureDefinitions { get; set; }
    }

    public class Child
    {
        public string type { get; set; }
        public IList<string> children { get; set; }
    }

    public class ParsedMessage
    {
        public string type { get; set; }
        //public IList<Child> children { get; set; }
    }

    public class Sender
    {
        public string senderType { get; set; }
        public string contactId { get; set; }
        public string username { get; set; }
        public string service { get; set; }
    }

    public class IdpMessagePayload
    {
        public String blastId { get; set; }
        public string counterpartyId { get; set; }
        public object forwarded { get; set; }
        public string id { get; set; }
        public string message { get; set; }
        public ParsedMessage parsedMessage { get; set; }
        public bool recognized { get; set; }
        public object serverAction { get; set; }
        public Sender sender { get; set; }
        public DateTime timestamp { get; set; }
        public bool isIncoming { get; set; }
        public bool isDeskMessage { get; set; }
        public bool isIntercomMessage { get; set; }
        public bool wasSentByCoworker { get; set; }
        public bool wasSentByUser { get; set; }
        public bool wasSentByUsersDesk { get; set; }
    }
}
