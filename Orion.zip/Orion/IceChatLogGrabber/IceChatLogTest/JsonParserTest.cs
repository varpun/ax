﻿using System;
using System.Linq;
using IceChatLogGrabber.Polling;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json.Linq;

namespace IceChatLogTest
{

    [TestClass]
    public class JsonParserTest
    {
        [TestMethod]
        public void MessageTest1()
        {
            JsonParser parser=new JsonParser();
            JObject o = JObject.Parse(@"{""eventName"":""log:write"",""payload"":{""level"":""info"",""args"":[""CommandChainDispatcher: dispatching event \""%s\"""",""contact:chatmessage:batch"",{""batch"":[{""idpMessagePayload"":[{""blastId"":null,""counterpartyId"":""tkiss1"",""forwarded"":null,""id"":""MessageLog-13468982848"",""message"":""Hello"",""parsedMessage"":{""type"":""message"",""children"":[{""type"":""line"",""children"":[""Hello""]}]},""priority"":0,""recognized"":false,""serverAction"":null,""sender"":{""senderType"":""contact"",""contactId"":""tkiss1"",""username"":""tkiss1"",""service"":""yj""},""timestamp"":""2017-05-10T12:03:43.239Z"",""isIncoming"":true,""isDeskMessage"":false,""isIntercomMessage"":false,""wasSentByCoworker"":false,""wasSentByUser"":false,""wasSentByUsersDesk"":false}],""webIceMessagePayload"":null,""structureDefinitions"":null}],""__executionId"":""03c90108-ef9e-41f4-a5f0-b5258c631476""}]}}");
            var parsingResult=parser.ProcessJsonMessage(o);

            Assert.AreEqual(1, parsingResult.Count());
            Assert.AreEqual("MessageLog-13468982848", parsingResult.First().IceMessageId);
            Assert.AreEqual("Hello", parsingResult.First().MessageText);
            Assert.AreEqual("tkiss1", parsingResult.First().UserName);

        }

        [TestMethod]
        public void MessageTest2()
        {
            JsonParser parser = new JsonParser();
            JObject o = JObject.Parse(@"{""eventName"":""log:write"",""payload"":{""level"":""info"",""args"":[""CommandChainDispatcher: dispatching event \""%s\"""",""contact:chatmessage:batch"",{""batch"":[{""idpMessagePayload"":[{""blastId"":""13507475545"",""counterpartyId"":""gav_hill2-yahoo"",""forwarded"":null,""id"":""MessageLog-13507478939"",""message"":""jun/jul fei 1.00/"",""parsedMessage"":{""type"":""message"",""children"":[{""type"":""line"",""children"":[{""type"":""market"",""market"":""jun/jul fei 1.00/"",""children"":[""jun/jul fei 1.00/""]}],""recognizedMarket"":{""quote"":"""",""structureId"":""Structure-10888007975"",""tick"":0,""standardizedMarketString"":null,""market"":""jun/jul fei 1.00/""}}]},""priority"":0,""recognized"":true,""serverAction"":null,""sender"":{""senderType"":""contact"",""fromUserHandle"":""ghill5"",""contactId"":""gav_hill2-yahoo"",""username"":""gav_hill2"",""service"":""yahoo""},""timestamp"":""2017-05-12T10:23:44.616Z"",""isIncoming"":true,""isDeskMessage"":false,""isIntercomMessage"":false,""wasSentByCoworker"":false,""wasSentByUser"":false,""wasSentByUsersDesk"":false}],""webIceMessagePayload"":null,""structureDefinitions"":null}],""__executionId"":""6374cba8-3528-4193-82ee-ada2152d32e4""}]}}");
            var parsingResult = parser.ProcessJsonMessage(o);

            Assert.AreEqual(1, parsingResult.Count());
            Assert.AreEqual("MessageLog-13507478939", parsingResult.First().IceMessageId);
            Assert.AreEqual("jun/jul fei 1.00/", parsingResult.First().MessageText);
            Assert.AreEqual("gav_hill2", parsingResult.First().UserName);

        }
    }
}
