﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using Mandara.MIA.Common;
using Mandara.MIA.CommonClient.PriceSyncClient;

namespace IceRtdTry1.Mia
{
    class MiaPublisher : PriceSyncCallback
    {
        private readonly Object _connectionLock = new object();
        private volatile PriceSyncClient _client;
        private NetTcpBinding _binding;
        private EndpointAddress _miaEndpointAddress;

        public PriceSyncClient Client
        {
            get
            {
                if (_client != null && _client.State == CommunicationState.Opened)
                {
                    //SubscribeProducts(databaseValues);
                    return _client;
                }
                else
                {
                    OpenClient();
                    return _client;
                }
            }
        }

        protected void OpenClient()
        {
            lock (_connectionLock)
            {
                if (_client == null || _client.State != CommunicationState.Opened)
                {

                    _client = new PriceSyncClient(new InstanceContext(this), _binding, _miaEndpointAddress);
                    _client.Open();
                    _client.Login(GetHostName(), GetUserName());
                }
            }
        }

        static string GetHostName()
        {
            try
            {
                // Get the local computer host name.
                return Dns.GetHostName();
            }
            catch (Exception)
            {
                return null;
            }
        }

        static string GetUserName()
        {
            return "TocomMini";
        }

        public void Init()
        {

            var recieveTimeout = TimeSpan.FromMilliseconds(10000);
            var sendTimeout = TimeSpan.FromMilliseconds(10000);

            string realAddress = ConfigurationManager.AppSettings["MiaServer"];


            _binding = new NetTcpBinding(SecurityMode.None, false)
            {
                TransferMode = TransferMode.Buffered,
                SendTimeout = sendTimeout,
                ReceiveTimeout = recieveTimeout,
                MaxReceivedMessageSize = int.MaxValue
            };

            _miaEndpointAddress = new EndpointAddress($"net.tcp://{realAddress}:8080/PriceSync");
        }

        public void Stop()
        {
            lock (_connectionLock)
            {
                if (_client != null && _client.State == CommunicationState.Opened)
                {
                    _client.Close();
                }
            }
        }

        public void UpdateData(PriceData[] data)
        {
            //
        }

        public void UpdatePrices(PriceData[] data, PriceData[] masterData)
        {
            //
        }

        public void UpdateMasterStatus(bool status, bool kick)
        {
            //
        }


        public void SendData(PriceData[] updates)
        {
            Client.SendData(updates);
        }
    }
}
