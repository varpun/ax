﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IceRtdTry1
{
    public class ProductMapping
    {
        public String Name { get; set; }
        public String Code { get; set; }
        public String BalmoCode { get; set; }
        public String SpreadCode { get; set; }

        public String SpreadBalmoCode { get; set; }

        public int OfficialProductId { get; set; }
        public bool IsOtc { get; set; }

        public ProductMapping()
        {
            IsOtc = true;
            SpreadBalmoCode = null;
        }
    }
}
