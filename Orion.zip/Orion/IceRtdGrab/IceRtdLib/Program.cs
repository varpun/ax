﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using IceRtdTry1.Mia;
using Mandara.MIA.Common;
using NLog;
using RTDServerLib;
using Timer = System.Timers.Timer;

namespace IceRtdTry1
{
    class Program : IRTDUpdateEvent
    {
        private ConcurrentDictionary<int,Tuple<string, FieldConfig,ProductMapping, object,string>> _topicMap = new ConcurrentDictionary<int,Tuple<string, FieldConfig, ProductMapping, object,string>>();
        private ConcurrentQueue<PriceData[]> _priceUpdates = new ConcurrentQueue<PriceData[]>();
        private volatile int _nextTopicId;
        private static IRtdServer _server;
        private static Logger _logger = LogManager.GetCurrentClassLogger();
        private static Program _instance;
        private List<ProductMapping> productMappings = new List<ProductMapping>();
        private FieldConfig[] fields;
        private Thread _publisherThread;
        private MiaPublisher _miaPublisher;
        private CancellationTokenSource _cancellationTokenSource = new CancellationTokenSource();

        static void Main(string[] args)
        {
            AppDomain.CurrentDomain.ProcessExit += CurrentDomain_ProcessExit;
            _instance = new Program();
            
            Console.WriteLine("Press any key to stop...");
            _instance.Run();
            Console.ReadKey();
            
            _instance.ShutDown();
        }

        private static void CurrentDomain_ProcessExit(object sender, EventArgs e)
        {
            try
            {
                _server?.ServerTerminate();
            }
            catch (Exception)
            {
            }
        }

        private void ShutDown()
        {
            _cancellationTokenSource?.Cancel();
            ForceTerminate();
            _publisherThread?.Join();
            _miaPublisher?.Stop();
        }

        Program()
        {
            _nextTopicId = 1;
            
        }

        private enum FieldType
        {
            PRICE,VOLUME,STRING,DATE
        }

        private class FieldConfig: Tuple<String,FieldType>
        {
            public FieldConfig(string item1, FieldType item2) : base(item1, item2)
            {
            }
        }

        public void Run()
        {
            try
            {
                Type rtd;
                Object rtdServer = null;
                rtd = Type.GetTypeFromProgID("ice.rtd");
                rtdServer = Activator.CreateInstance(rtd);

                _server = (IRtdServer) rtdServer;
                _server.ServerStart(this);
                _miaPublisher = new MiaPublisher();
                _miaPublisher.Init();
                _logger.Info("Mia connected {0}", _miaPublisher.Client.State);

                InitStaticConfig();
                _publisherThread = new Thread(PublishPrices);
                
                SubscribeMarkets();
                Thread.Sleep(300);
                _publisherThread.Start();
            }
            catch (Exception e)
            {
                _logger.Error(e,"Exception during subscription");
            }
            
        }

        private void PublishPrices()
        {
            DateTime _lastUpdate = DateTime.UtcNow;
            while (!_cancellationTokenSource.Token.IsCancellationRequested)
            {
                List<PriceData[]> updates = new List<PriceData[]>();
                PriceData[] item;
                while (_priceUpdates.TryDequeue(out item))
                {
                    updates.Add(item);
                }
                if (updates.Count > 0)
                {
                    var array = updates.SelectMany(x => x).ToArray();
                    _logger.Info("Sending {0} updates",array.Length);
                    _miaPublisher.SendData(array);
                    _logger.Trace("Data sent:");
                    _logger.Trace("({0})",String.Join(";",array.Select(x=>x.ToString())));
                    _lastUpdate = DateTime.UtcNow;
                }
                else
                {
                    if (DateTime.UtcNow.Subtract(_lastUpdate) > TimeSpan.FromSeconds(10))
                    {
                        _logger.Info("Pinging MIA");
                        _miaPublisher.Client.Ping();
                        _lastUpdate = DateTime.UtcNow;
                    }
                    Thread.Sleep(100);
                }
            }
        }

        private void SubscribeMarkets()
        {
            foreach (var mapping in productMappings)
            {
                SubscribeAll(GetMonthCode(mapping), mapping);
                if (mapping.IsOtc)
                {
                    SubscribeAll(GetQuarterCode(mapping),  mapping);
                    SubscribeAll(GetYearCode(mapping),  mapping);
                    SubscribeAll(GetBalmoCode(mapping),  mapping);
                }
                if (!String.IsNullOrEmpty(mapping.SpreadCode))
                {
                    SubscribeAll(GetMonthSpreadCode(mapping.SpreadCode),  mapping);
                    if (mapping.IsOtc)
                    {
                        SubscribeAll(GetQuarterSpreadCode(mapping.SpreadCode),  mapping);
                        SubscribeAll(GetYearSpreadCode(mapping.SpreadCode),  mapping);
                        if (String.IsNullOrEmpty(mapping.SpreadBalmoCode))
                        {
                            SubscribeAll(GetBalmoSpreadCode(mapping.SpreadCode),  mapping);
                        }
                        else
                        {
                            SubscribeAll(GetBalmoSpreadCode(mapping.SpreadBalmoCode),  mapping);
                        }
                    }
                }
            }
        }

        #region StaticConfig

        private void InitStaticConfig()
        {
            productMappings.Add(new ProductMapping()
            {
                Name = "Sing 180",
                Code = "209",
                SpreadCode = "1079",
                BalmoCode = "15161312",
                OfficialProductId = 5
            });
            productMappings.Add(new ProductMapping()
            {
                Name = "Sing 380",
                Code = "365531",
                SpreadCode = "366531",
                BalmoCode = "15171344",
                OfficialProductId = 7
            });
            productMappings.Add(new ProductMapping()
            {
                Name = "3.5 Barges",
                Code = "2212",
                SpreadCode = "11012",
                BalmoCode = "18961756",
                OfficialProductId = 6
            });
            productMappings.Add(new ProductMapping()
            {
                Name = "Visco",
                Code = "266419",
                SpreadCode = "1486419",
                BalmoCode = "18981820",
                OfficialProductId = 28
            });
            productMappings.Add(new ProductMapping()
            {
                Name = "Brent 1st Line/Dubai 1st Line",
                Code = "141587",
                BalmoCode = null,
                OfficialProductId = 54
            });
            productMappings.Add(new ProductMapping()
            {
                Name = "EW",
                Code = "88690",
                SpreadCode = "1247690",
                BalmoCode = "18941692",
                SpreadBalmoCode = "12475895",
                OfficialProductId = 29
            });
            productMappings.Add(new ProductMapping()
            {
                Name = "380 EW",
                Code = "30793693",
                BalmoCode = "30803801",
                OfficialProductId = 50
            });
            productMappings.Add(new ProductMapping() {Name = "Crack", Code = "5162", OfficialProductId = 32});
            productMappings.Add(new ProductMapping()
            {
                Name = "3% GC",
                Code = "18921689",
                SpreadCode = "1091689",
                BalmoCode = "29203567",
                SpreadBalmoCode = "1098472",
                OfficialProductId = 10
            });
            productMappings.Add(new ProductMapping()
            {
                Name = "Us Arb",
                Code = "18911688",
                BalmoCode = "30763769",
                OfficialProductId = 30
            });
            productMappings.Add(new ProductMapping()
            {
                Name = "Lo/Hi",
                Code = "266",
                SpreadCode = "12466",
                BalmoCode = "25632493",
                OfficialProductId = 31
            });
            productMappings.Add(new ProductMapping()
            {
                Name = "1% Cargo",
                Code = "237",
                SpreadCode = "1478331",
                BalmoCode = "20782110",
                SpreadBalmoCode = "1087",
                OfficialProductId = 8
            });
            productMappings.Add(new ProductMapping()
            {
                Name = "MOPJ",
                Code = "18861684",
                SpreadCode = "42661684",
                BalmoCode = "28483312",
                OfficialProductId = 1229
            });
            productMappings.Add(new ProductMapping()
            {
                Name = "NWE",
                Code = "18841682",
                SpreadCode = "34721682",
                BalmoCode = "25673018",
                OfficialProductId = 1221
            });
            productMappings.Add(new ProductMapping()
            {
                Name = "NWE Crack",
                Code = "18851683",
                BalmoCode = "28503376",
                OfficialProductId = 1232
            });
            productMappings.Add(new ProductMapping() {Name = "Naphtha E/W", Code = "18871685", OfficialProductId = 1234});
            productMappings.Add(new ProductMapping() {Name = "RBOB", Code = "30723689", OfficialProductId = 1235});
            //productMappings.Add(new ProductMapping() { Name = "RBOB Crack", Code = "29233601", OfficialProductId = 1236 });
            productMappings.Add(new ProductMapping() {Name = "EBOB", Code = "20831945", OfficialProductId = 1237});
            productMappings.Add(new ProductMapping()
            {
                Name = "EBOB Crack",
                Code = "18901687",
                BalmoCode = "20852078",
                OfficialProductId = 1238
            });
            productMappings.Add(new ProductMapping()
            {
                Name = "Sing Kero",
                Code = "124190",
                SpreadCode = "126190",
                BalmoCode = "15201440",
                OfficialProductId = 1220
            });
            productMappings.Add(new ProductMapping()
            {
                Name = "0.05% Sing",
                Code = "40734933",
                SpreadCode = "40924933",
                BalmoCode = "40744965",
                OfficialProductId = 1219
            });


            //productMappings.Add(new ProductMapping() { Name = "Brent Future", Code = "BRN254",SpreadCode = "BRN258", BalmoCode = null, IsOtc=false });


            fields = new[]
            {
                new FieldConfig("BstHitPrc", FieldType.PRICE),
                new FieldConfig("BstHitQty", FieldType.VOLUME),
                new FieldConfig("BstLiftPrc", FieldType.PRICE),
                new FieldConfig("BstLiftQty", FieldType.VOLUME),
                new FieldConfig("LstQty", FieldType.VOLUME),
                new FieldConfig("LstPrc", FieldType.PRICE),
                new FieldConfig("LstType", FieldType.STRING),
                new FieldConfig("Vol", FieldType.VOLUME),
                new FieldConfig("BlkVol", FieldType.VOLUME),
                new FieldConfig("BlkPrc", FieldType.PRICE),
                new FieldConfig("LstBlkVol", FieldType.VOLUME),
                new FieldConfig("Avg", FieldType.PRICE),
                new FieldConfig("Settle", FieldType.PRICE),
                new FieldConfig("Change", FieldType.PRICE),
                new FieldConfig("MktState", FieldType.STRING),
                new FieldConfig("High", FieldType.PRICE),
                new FieldConfig("Low", FieldType.PRICE),
                new FieldConfig("TrdBidQty", FieldType.VOLUME),
                new FieldConfig("TrdBidPrc", FieldType.PRICE),
                new FieldConfig("TrdOffQty", FieldType.VOLUME),
                new FieldConfig("TrdOffPrc", FieldType.PRICE),
                new FieldConfig("LstDate", FieldType.DATE)


            };
        }
        #endregion

        private void SubscribeAll(IEnumerable<Tuple<string,string>> codes, ProductMapping mapping)
        {
            foreach (var code in codes)
            {
                foreach (var field in fields)
                {
                    Subscribe(code, mapping, field);
                }
                var miaInitialValues =
                    fields.Select(x => $"ICEBO.{mapping.OfficialProductId}.{x.Item1}")
                        .Select(x => new PriceData(x, code.Item2, Double.NaN, ""))
                        .ToArray();
                _priceUpdates.Enqueue(miaInitialValues);
            }
            
        }

        private IEnumerable<Tuple<string, string>> GetMonthCode(ProductMapping mapping)
        {
            Func<int, string> func = (i) =>
            {
                var month = GetNow().AddMonths(i);
                return month.ToString("MMMyy");
            };
            return GetCodeGeneric(mapping.Code,"M" , 16,func);
        }

        private IEnumerable<Tuple<string, string>> GetMonthSpreadCode(string code)
        {
            Func<int, string> func = (i) =>
            {
                var month1 = GetNow().AddMonths(i);
                var month2 = month1.AddMonths(1);
                return $"{month1:MMMyy}/{month2:MMMyy}";
            };
            return GetCodeGeneric(code, "MM", 12,func);
        }

        private IEnumerable<Tuple<string, string>> GetBalmoSpreadCode(string code)
        {
            Func<int, string> func = (i) =>
            {
                var month = DateTime.Now.AddMonths(1);
                var firstPart = i == 0 ? "Bal Month" : "Bal Month-ND";
                return $"{firstPart}/{month:MMMyy}";
            };
            return GetCodeGeneric(code, "BM", 1,func);
        }

        private IEnumerable<Tuple<string, string>> GetYearSpreadCode(string code)
        {
            Func<int, string> func = (i) =>
            {
                var year1 = GetNow().AddYears(i+1);
                var year2 = year1.AddYears(1);
                return $"Cal {year1:yy}/Cal {year2:yy}";
            };
            return GetCodeGeneric(code, "YY", 2,func);
        }

        private IEnumerable<Tuple<string, string>> GetQuarterSpreadCode(string code)
        {
            Func<int, string> func = (i) =>
            {

                var baseMonth = GetNow().AddMonths(1);
                while (baseMonth.Month % 3 != 0) baseMonth = baseMonth.AddMonths(1);
                var q1 = baseMonth.AddMonths(i * 3);
                var q2 = q1.AddMonths(3);
                return $"Q{q1.Month/3} {q1:yy}/Q{q2.Month / 3} {q2:yy}";
            };

            return GetCodeGeneric(code, "QQ", 8,func);
        }

        private DateTime GetNow()
        {
            return new DateTime(DateTime.Now.Year,DateTime.Now.Month,1);
        }

        private IEnumerable<Tuple<string, string>> GetQuarterCode(ProductMapping mapping)
        {
            Func<int, string> func = (i) =>
            {
                var baseMonth = GetNow().AddMonths(1);
                while (baseMonth.Month % 3 != 0) baseMonth = baseMonth.AddMonths(1);
                var q1 = baseMonth.AddMonths(i * 3);
                return $"Q{q1.Month / 3} {q1:yy}";
            };
            return GetCodeGeneric(mapping.Code, "Q", 10,func);
        }

        private IEnumerable<Tuple<string, string>> GetYearCode(ProductMapping mapping)
        {
            Func<int, string> func = (i) =>
            {
                var year = GetNow().AddYears(i+1);
                return $"Cal {year:yy}";
            };
            return GetCodeGeneric(mapping.Code, "Y", 2,func);
        }

        private IEnumerable<Tuple<string,string>> GetBalmoCode(ProductMapping mapping)
        {
            if (!String.IsNullOrEmpty(mapping.BalmoCode))
            {
                Func<int,string> func = (i) => i == 0 ? "Balmo" : "Balmo-ND";
                return GetCodeGeneric(mapping.BalmoCode, "B", 1,func );
            }
            else
            {
                return new List<Tuple<string, string>>();
            }
        }

        private IEnumerable<Tuple<string,string>> GetCodeGeneric(string code, string classifier, int maxNum, Func<int,string> stripFunc )
        {
            for (int i = 0; i <= maxNum; i++)
            {
                yield return new Tuple<string, string>($"{code}{classifier}{i}", stripFunc.Invoke(i));
            }
        }

        private void Subscribe(Tuple<string,string> codeStripTuple, ProductMapping mapping, FieldConfig field)
        {
            String key = codeStripTuple.Item1 + ":" + field.Item1;
            _logger.Info("Subscribing for {0}",key);
            Array topics = new object[] {key};
            bool newValue=false;
            _topicMap[_nextTopicId] = new Tuple<string, FieldConfig ,ProductMapping,object,string>(key, field ,mapping, null,codeStripTuple.Item2);
            Object initialData = _server.ConnectData(_nextTopicId, ref topics, ref newValue);
            _topicMap[_nextTopicId] = new Tuple<string, FieldConfig ,ProductMapping, object,string>(key, field ,mapping, initialData, codeStripTuple.Item2);
            _nextTopicId++;
            
        }

        private void ForceTerminate()
        {
            _logger.Info("Shutting down");
            try
            {
                _server?.ServerTerminate();
                _topicMap.Clear();
            }
            catch (COMException)
            {
            }
        }

        public void UpdateNotify()
        {
            try
            {
                
                int topicUpdated=0;
                Array newData = _server.RefreshData(ref topicUpdated);
                object[,] returnValues = (object[,]) newData;
                _logger.Info("Update received {0}",topicUpdated);
                List<PriceData> updates =  new List<PriceData>(topicUpdated/2);
                for (int i = 0; i < topicUpdated; i++)
                {
                    int topicId = Convert.ToInt32(returnValues[0, i]);
                    var entry = _topicMap[topicId];
                    String key = entry.Item1;
                    String productName = entry.Item3.Name;
                    object value = returnValues[1, i];
                    _logger.Info("Data on ({1},{2},{3})={0}", value, key, topicId,productName);
                    var data = MapPriceData(value, entry.Item5, entry.Item2, entry.Item3);
                    if (!String.IsNullOrEmpty(data.GetProductInfo().Name))
                    {
                        updates.Add(data);
                    }
                    
                }
                _priceUpdates.Enqueue(updates.ToArray());
            }
            catch (Exception e)
            {
                _logger.Error(e,"Error during processing update");
            }
        }

        

        private PriceData MapPriceData(object value,String strip, FieldConfig field, ProductMapping mapping)
        {
            String key = $"ICEBO.{mapping.OfficialProductId}.{field.Item1}";
            PriceData data= new PriceData();
            if (value.ToString().Contains("Invalid"))
            {
                _logger.Warn("Missing value for {0}{1} {2}",mapping.Name, strip, value);
                return data;
            }
            switch (field.Item2)
            {
                
                case FieldType.PRICE:
                    double parsedDouble=Double.NaN;
                    if (Double.TryParse(value.ToString(), out parsedDouble) || String.IsNullOrEmpty(value.ToString()))
                    {
                        data = new PriceData(key, strip, parsedDouble, "");
                    }
                    else
                    {
                        _logger.Warn("Cannot parse value {0} for {1}{2}", value, mapping.Name, strip);
                    }
                    break;
                case FieldType.VOLUME:
                    int parsedInt=0;
                    if (Int32.TryParse(value.ToString(), out parsedInt) || String.IsNullOrEmpty(value.ToString()))
                    {
                        data = new PriceData(key, strip, parsedInt, "");
                    }
                    else
                    {
                        _logger.Warn("Cannot parse value {0} for {1}{2}", value, mapping.Name, strip);
                    }
                    break;
                case FieldType.STRING:
                    data = new PriceData(key, strip, Double.NaN, value.ToString());
                    break;
                case FieldType.DATE:
                    double d = Double.Parse(value.ToString());
                    DateTime date = DateTime.FromOADate(d);
                    data = new PriceData(key, strip, Double.NaN, date.ToString("u"));
                    break;
            }
            return data;
        }

        public void Disconnect()
        {
            _logger.Warn("Disconnected");
        }

        public int HeartbeatInterval { get; set; }
    }
}
